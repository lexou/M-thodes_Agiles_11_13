interface ActionBatman {
    public void action();
}

class Batmobile implements ActionBatman {
    public void action() {
        System.out.println("Batman se déplace avec la Batmobile");
    }
}
class Telephone implements ActionBatman {
    public void action() {
        System.out.println("Batman répond au téléphone");
    }
}
class Boutique implements ActionBatman {
    public void action() {
        System.out.println("Batman achète un téléphone");
    }
}
class Batman {
    private ActionBatman actionBatman;
    public Batman(ActionBatman actionBatman) {
        this.actionBatman = actionBatman;
    }
    public void setActionBatman(ActionBatman actionBatman) {
        this.actionBatman = actionBatman;
    }
    public void executeAction() {
        actionBatman.action();
    }
}
