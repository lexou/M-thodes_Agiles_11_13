
/**
 * Décrivez votre classe Batmobile ici.
 *
 * @author (votre nom)
 * @version (un numéro de version ou une date)
 */
public class Batmobile
{
    private Batman batman;
    /**
     * Constructeur d'objets de classe Batmobile
     */

    public Batmobile(Batman batman) {
        // initialisation des variables d'instance
        this.batman = batman;
    }
 
    public void vitesseBatmobile() {
        batman.accelerer(50);   
    }

    public Batman getBatman() {
        return batman;
    }

    public void setBatman(Batman batman) {
        this.batman = batman;
    }
    
    /**
     * Un exemple de méthode - remplacez ce commentaire par le vôtre
     *
     * @param  y   le paramètre de la méthode
     * @return     la somme de x et de y
     */
    
}
