package BatmanPackage;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class VitesseBat {
    @Given("^creation de la (\\d+) de Batman$")
    public void creationDeLaVitesseDeBatman() {
    }
    @When("^l'utilisateur valide$")
    public void lUtilisateurValide() {
        throw new io.cucumber.java.PendingException();
    }

    @Then("^l'accélération de Batman est calculée$")
    public void lAccélérationDeBatmanEstCalculée() {
        throw new io.cucumber.java.PendingException();
    }


    @Then("^l'(\\d+) de Batman est calculée$")
    public void lAccelerationDeBatmanEstCalculée() {

    }
}
