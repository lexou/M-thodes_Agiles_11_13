interface Equipement {
    public void utiliser();
}
class Batmobile implements Equipement {
    public void utiliser() {
        System.out.println("Utilise la Batmobile");
    }
}
class Telephone implements Equipement {
    public void utiliser() {
        System.out.println("Utilise le telephone");
    }
}
class BoutiqueTelephone implements Equipement {
    private List<Equipement> equipements = new ArrayList<Equipement>();
    public void add(Equipement equipement) {
        equipements.add(equipement);
    }
    public void remove(Equipement equipement) {
        equipements.remove(equipement);
    }
    public void utiliser() {
        for (Equipement equipement : equipements) {
            equipmeent.utiliser();
        }
    }
}
class Batman {
    private BoutiqueTelephone boutiqueTelephone;
    private Batmobile batmobile;
    public Batman() {
        boutiqueTelephone = new BoutiqueTelephone();
        boutiqueTelephone.add(new Telephone());
        batmobile = new Batmobile();
    }
    public void utiliserEquipement() {
        boutiqueTelephone.utiliser();
        batmobile.utiliser();
    }
}
