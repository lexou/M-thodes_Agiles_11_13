
/**
 * Décrivez votre classe Batman ici.
 *
 * @author (votre nom)
 * @version (un numéro de version ou une date)
 */
public class Batman
{
    // variables d'instance - remplacez l'exemple qui suit par le vôtre
    private float vitesse;
    //private Batmobile batmobile;
    /**
     * Constructeur d'objets de classe Batman
     */
    public Batman(float vitesse)
    {
        // initialisation des variables d'instance
        this.vitesse = vitesse;
        //Batman heros = new Batman(vitesse);
        //heros.vitesse = 0;
    }

    /**
     la méthode accélérer qui prend en paramètre la variable vitesse
     */
    
    public float getVitesse() {
        return vitesse;
    }
    public void setVitesse(float vitesse) {
       this.vitesse = vitesse;
    }
    public float accelerer(float deltaVitesse) {
        vitesse = vitesse + deltaVitesse;
        return vitesse;
    } 
    
    //public void voiture(Batmobile batmobile){
    //    this.batmobile = batmobile;
    //}
}
