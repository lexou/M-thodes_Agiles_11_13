package code;

import static org.junit.jupiter.api.Assertions.*;

class BoutiqueTelephoneTest {

    @org.junit.jupiter.api.Test
    void add() {
        Telephone t1 = new Telephone("ip7", 2017);
        BoutiqueTelephone boutique = new BoutiqueTelephone("apple");
        boutique.add(t1);

    }

    @org.junit.jupiter.api.Test
    void afficheTelephoneAge() {
        Telephone t1 = new Telephone("ip7", 2017);
        BoutiqueTelephone boutique = new BoutiqueTelephone("apple");
        boutique.add(t1);
        assertEquals(5, boutique.afficheTelephoneAge(t1));
    }
}