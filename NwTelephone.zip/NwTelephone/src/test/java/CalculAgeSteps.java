import io.cucumber.java.en.Given;

public class CalculAgeSteps {
    

    @io.cucumber.java.en.And("^I have son <AnneeFabrique>$")
    public void iHaveSonAnneeFabrique() {
    }

    @io.cucumber.java.en.And("^I have son numero <siret>$")
    public void iHaveSonNumeroSiret() {
    }

    @io.cucumber.java.en.When("^I want to know if it is old or not$")
    public void iWantToKnowIfItIsOldOrNot() {
    }

    @io.cucumber.java.en.Then("^I should have its <age> in years$")
    public void iShouldHaveItsAgeInYears() {
    }

    @Given("I have the <marque> of the telephone")
    public void iHaveTheMarqueOfTheTelephone() {
    }
}
